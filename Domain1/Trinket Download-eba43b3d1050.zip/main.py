#114
print(type("This is a quiz on data types"))
print(type(True))
print(type("20000"))
print(type(2.22))
print(type(20000))
#113
number_of_tries = 3
multiplier = 1.5
print(number_of_tries / multiplier)
number_of_tries = 3
multiplier = 1.5
total = number_of_tries * multiplier
print(int(total))
