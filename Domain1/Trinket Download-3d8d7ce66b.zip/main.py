first_name = "Jason"
last_name = "Manibog"
print (first_name , last_name) 